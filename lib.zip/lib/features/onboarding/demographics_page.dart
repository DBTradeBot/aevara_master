// lib/features/onboarding/demographics_page.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../data/models/user_profile.dart'; // <- contains the Gender enum
import '../../routing/route_paths.dart';
import '../../state/user_providers.dart';

class DemographicsPage extends ConsumerStatefulWidget {
  const DemographicsPage({super.key});
  @override
  ConsumerState<DemographicsPage> createState() => _DemographicsPageState();
}

class _DemographicsPageState extends ConsumerState<DemographicsPage> {
  DateTime? _dob;
  Gender? _gender; // <- enum, not String
  bool _loading = false;

  Future<void> _pickDob() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(now.year - 25, now.month, now.day),
      firstDate: DateTime(now.year - 100),
      lastDate: now,
    );
    if (picked != null) setState(() => _dob = picked);
  }

  Future<void> _submit() async {
    if (_dob == null || _gender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose your date of birth and gender.')),
      );
      return;
    }
    setState(() => _loading = true);
    try {
      final user = FirebaseAuth.instance.currentUser!;
      final svc = ref.read(userProfileServiceProvider);
      final current = await svc.watchProfile(user.uid).first;
      final updated = (current ??
          UserProfile(
            uid: user.uid,
            email: user.email ?? '',
            username: '',
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          ))
          .copyWith(
        dob: _dob,
        gender: _gender, // <- enum
        updatedAt: DateTime.now(),
      );
      await svc.createOrUpdate(updated);
      if (mounted) Navigator.pushNamed(context, RoutePaths.consent);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final df = DateFormat.yMMMMd(); // April 15, 1992

    return Scaffold(
      appBar: AppBar(title: const Text('Demographics')),
      body: SafeArea(
        minimum: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date of birth', style: theme.textTheme.labelLarge),
            const SizedBox(height: 8),
            InkWell(
              onTap: _pickDob,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: theme.colorScheme.outlineVariant),
                ),
                child: Text(_dob == null ? 'Select date' : df.format(_dob!)),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<Gender>(
              value: _gender,
              items: [
                const DropdownMenuItem(value: Gender.male, child: Text('Male')),
                const DropdownMenuItem(value: Gender.female, child: Text('Female')),
                DropdownMenuItem(value: Gender.other, child: const Text('Other / prefer not to say')),
              ],
              onChanged: (v) => setState(() => _gender = v),
              decoration: const InputDecoration(labelText: 'Gender'),
            ),
            const Spacer(),
            FilledButton(
              onPressed: _loading ? null : _submit,
              child: _loading ? const CircularProgressIndicator() : const Text('Continue'),
            ),
          ],
        ),
      ),
    );
  }
}
