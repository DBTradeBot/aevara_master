// lib/app.dart
import 'package:flutter/material.dart';
import 'routing/routes.dart';
import 'routing/route_paths.dart';

class AevaraApp extends StatelessWidget {
  const AevaraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aevara',
      debugShowCheckedModeBanner: false,
      initialRoute: RoutePaths.signin,
      onGenerateRoute: onGenerateRoute,
      // If you have a theme file, wire it here
      // theme: AppTheme.light,
      // darkTheme: AppTheme.dark,
    );
  }
}
