// lib/core/widgets/dev_fab_navigator.dart
import 'package:flutter/material.dart';
import '../../routing/route_paths.dart';

class DevFabNavigator extends StatelessWidget {
  const DevFabNavigator({super.key});

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      heroTag: 'dev_fab_nav',
      onPressed: () {
        showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          isScrollControlled: true,
          builder: (ctx) => const _DevNavSheet(),
        );
      },
      icon: const Icon(Icons.bug_report),
      label: const Text('Dev'),
    );
  }
}

class _DevNavSheet extends StatelessWidget {
  const _DevNavSheet();

  Widget _section(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
    child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
  );

  Widget _item(BuildContext context, String label, String path) => ListTile(
    dense: true,
    title: Text(label),
    trailing: const Icon(Icons.chevron_right_rounded),
    onTap: () {
      Navigator.pop(context);
      Navigator.pushNamed(context, path);
    },
  );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          _section('/ AUTH'),
          _item(context, '/auth/signin', RoutePaths.signin),
          _item(context, '/auth/signup', RoutePaths.signup),
          _item(context, '/auth/verify', RoutePaths.verify),
          _item(context, '/auth/forgot', RoutePaths.forgot),
          _section('/ ONBOARDING'),
          _item(context, '/onboarding/identity', RoutePaths.identity),
          _item(context, '/onboarding/demographics', RoutePaths.demographics),
          _item(context, '/onboarding/consent', RoutePaths.consent),
          _item(context, '/onboarding/connect', RoutePaths.connect),
          _item(context, '/onboarding/ready', RoutePaths.ready),
          _section('/ APP'),
          _item(context, '/app/home', RoutePaths.home),
        ],
      ),
    );
  }
}
