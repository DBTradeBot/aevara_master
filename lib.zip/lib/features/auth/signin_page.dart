import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../routing/route_paths.dart';
import 'components/auth_email_field.dart';
import 'components/auth_password_field.dart';
import 'components/oauth_google_button.dart';
import 'components/auth_alt_links_row.dart';
import 'components/submit_buttons.dart';
import '../../core/widgets/dev_fab_navigator.dart';

class SignInPage extends ConsumerStatefulWidget {
  const SignInPage({super.key});
  @override
  ConsumerState<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends ConsumerState<SignInPage> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _doSignIn() async {
    setState(() { _loading = true; _error = null; });
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email.text.trim(), password: _pass.text);
      if (mounted) Navigator.pushReplacementNamed(context, RoutePaths.identity); // guards will route onward
    } on FirebaseAuthException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      floatingActionButton: const DevFabNavigator(),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: ListView(
                shrinkWrap: true,
                children: [
                  Text('brand.ai', style: theme.textTheme.headlineSmall),
                  const SizedBox(height: 24),
                  Text('Welcome Back', style: theme.textTheme.titleLarge),
                  const SizedBox(height: 8),
                  Text("Let's get started by filling out the form below.", style: theme.textTheme.bodySmall),
                  const SizedBox(height: 24),
                  AuthEmailField(controller: _email),
                  const SizedBox(height: 12),
                  AuthPasswordField(controller: _pass),
                  const SizedBox(height: 16),
                  PrimarySubmitButton(label: 'Sign in', onPressed: _doSignIn, loading: _loading),
                  const SizedBox(height: 12),
                  Center(child: Text('OR', style: theme.textTheme.labelMedium)),
                  const SizedBox(height: 12),
                  OauthGoogleButton(onPressed: () {
                    // TODO: wire google oauth via google_sign_in on platforms
                  }),
                  const SizedBox(height: 12),
                  AuthAltLinksRow(isSignin: true),
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(_error!, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.error)),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
