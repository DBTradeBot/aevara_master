import 'package:flutter/material.dart';
import '../../routing/route_paths.dart';
import '../../core/widgets/dev_fab_navigator.dart';

class ReadyPage extends StatelessWidget {
  const ReadyPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: const DevFabNavigator(),
      appBar: AppBar(title: const Text("You're set")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Your account is ready. Continue to your dashboard.'),
            const Spacer(),
            FilledButton(onPressed: ()=>Navigator.pushReplacementNamed(context, RoutePaths.home), child: const Text('Go to Dashboard')),
          ],
        ),
      ),
    );
  }
}
