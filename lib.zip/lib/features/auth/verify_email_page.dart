import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../../routing/route_paths.dart';
import '../../core/widgets/dev_fab_navigator.dart';

class VerifyEmailPage extends StatefulWidget {
  const VerifyEmailPage({super.key});
  @override
  State<VerifyEmailPage> createState() => _VerifyEmailPageState();
}

class _VerifyEmailPageState extends State<VerifyEmailPage> {
  bool _loading = false;
  String? _status;

  Future<void> _resend() async {
    setState(() { _loading = true; _status = null; });
    try {
      await FirebaseAuth.instance.currentUser?.sendEmailVerification();
      setState(() => _status = 'Verification email sent.');
    } catch (e) {
      setState(() => _status = 'Failed: $e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _imVerified() async {
    await FirebaseAuth.instance.currentUser?.reload();
    final verified = FirebaseAuth.instance.currentUser?.emailVerified ?? false;
    if (!mounted) return;
    if (verified) {
      Navigator.pushReplacementNamed(context, RoutePaths.identity);
    } else {
      setState(() => _status = 'Not verified yet. Check your inbox.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: const DevFabNavigator(),
      appBar: AppBar(title: const Text('Verify your email')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('We sent a link to your email. Open it to verify, then tap the button below.'),
            const SizedBox(height: 16),
            FilledButton(onPressed: _loading ? null : _resend, child: const Text('Resend verification email')),
            const SizedBox(height: 8),
            FilledButton(onPressed: _imVerified, child: const Text("I'm verified")),
            const Spacer(),
            if (_status != null) Text(_status!),
          ],
        ),
      ),
    );
  }
}
