import 'package:flutter/material.dart';
import '../../routing/route_paths.dart';
import '../auth/components/submit_buttons.dart';
import '../../core/widgets/dev_fab_navigator.dart';

class ConnectPage extends StatelessWidget {
  const ConnectPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: const DevFabNavigator(),
      appBar: AppBar(title: const Text('Connect a device')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Expanded(child: GridView.count(
              crossAxisCount: 2,
              childAspectRatio: 1.6,
              children: const [
                _DeviceTile(name: 'Apple Health'),
                _DeviceTile(name: 'Google Fit'),
                _DeviceTile(name: 'Garmin'),
                _DeviceTile(name: 'Oura'),
                _DeviceTile(name: 'WHOOP'),
              ],
            )),
            Row(
              children: [
                OutlinedButton(onPressed: ()=>Navigator.pushNamed(context, RoutePaths.ready), child: const Text('Skip')),
                const Spacer(),
                PrimarySubmitButton(label: 'Continue', onPressed: ()=>Navigator.pushNamed(context, RoutePaths.ready)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DeviceTile extends StatelessWidget {
  final String name;
  const _DeviceTile({required this.name});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {/* TODO: provider sheet / oauth */},
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [const Icon(Icons.link), const SizedBox(width: 8), Expanded(child: Text(name))]),
        ),
      ),
    );
  }
}
