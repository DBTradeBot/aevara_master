// lib/features/onboarding/identity_page.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/utils/validators.dart';
import '../../state/user_providers.dart';
import '../../data/models/user_profile.dart';
import '../../routing/route_paths.dart';

class IdentityPage extends ConsumerStatefulWidget {
  const IdentityPage({super.key});
  @override
  ConsumerState<IdentityPage> createState() => _IdentityPageState();
}

class _IdentityPageState extends ConsumerState<IdentityPage> {
  final _formKey = GlobalKey<FormState>();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _handle = TextEditingController();

  bool _checking = false;
  bool? _available;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _handle.addListener(_onHandleChanged);
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _handle.removeListener(_onHandleChanged);
    _first.dispose();
    _last.dispose();
    _handle.dispose();
    super.dispose();
  }

  void _onHandleChanged() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), _checkAvailability);
  }

  Future<void> _checkAvailability() async {
    final raw = _handle.text;
    if (!Validators.usernameFormatOk(raw)) {
      setState(() => _available = false);
      return;
    }
    setState(() {
      _checking = true;
      _available = null;
    });
    try {
      final svc = ref.read(userProfileServiceProvider);
      final ok = await svc.isUsernameAvailable(Validators.normalizeHandle(raw).toLowerCase());
      setState(() => _available = ok);
    } catch (_) {
      setState(() => _available = false);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<void> _reserveAndContinue() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_available != true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please choose an available username.')),
      );
      return;
    }

    final callable = ref.read(reserveUsernameCallableProvider);
    final uid = ref.read(currentUserIdProvider);
    final svc = ref.read(userProfileServiceProvider);
    if (uid == null) return;

    final usernameRaw = Validators.normalizeHandle(_handle.text);
    try {
      // 👇 explicit generic to silence inference warning
      await callable.call<Map<String, dynamic>>(<String, dynamic>{'username': usernameRaw});

      final current = await svc.watchProfile(uid).first;
      final merged = (current ??
          UserProfile(
            uid: uid,
            email: '',
            username: usernameRaw,
            firstName: _first.text.trim(),
            lastName: _last.text.trim(),
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          ))
          .copyWith(
        firstName: _first.text.trim(),
        lastName: _last.text.trim(),
        username: usernameRaw,
        updatedAt: DateTime.now(),
      );

      await svc.createOrUpdate(merged);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Username reserved ✓')),
      );
      Navigator.pushNamed(context, RoutePaths.demographics);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not reserve: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide(color: theme.colorScheme.outlineVariant),
    );

    Widget availability() {
      if (_checking) {
        return const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Row(children: [SizedBox.square(dimension: 16, child: CircularProgressIndicator(strokeWidth: 2)), SizedBox(width: 8), Text('Checking…')]),
        );
      }
      if (_available == true) {
        return const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Row(children: [Icon(Icons.check_circle, color: Colors.green), SizedBox(width: 8), Text('Available')]),
        );
      }
      if (_available == false && _handle.text.isNotEmpty) {
        return const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Row(children: [Icon(Icons.error, color: Colors.redAccent), SizedBox(width: 8), Text('Not available')]),
        );
      }
      return const SizedBox.shrink();
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Choose your username')),
      body: SafeArea(
        minimum: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Text('This will be your public handle', style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('Use 3–20 characters: letters, numbers, underscore or dot.', style: theme.textTheme.bodySmall),
              const SizedBox(height: 20),

              TextFormField(
                controller: _first,
                decoration: InputDecoration(labelText: 'First name', border: border),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'First name is required' : null,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _last,
                decoration: InputDecoration(labelText: 'Last name', border: border),
                validator: (v) => (v == null || v.trim().isEmpty) ? 'Last name is required' : null,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 12),

              TextFormField(
                controller: _handle,
                decoration: InputDecoration(labelText: 'Username', prefixText: '@', border: border),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (v) => Validators.usernameFormatOk(v ?? '')
                    ? null
                    : 'Only a–z, 0–9, underscore, dot (3–20)',
              ),
              availability(),
              const SizedBox(height: 20),

              FilledButton(
                onPressed: (_available == true) ? _reserveAndContinue : null,
                child: const Text('Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
